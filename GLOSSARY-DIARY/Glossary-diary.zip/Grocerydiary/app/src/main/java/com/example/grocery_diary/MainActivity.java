package com.example.grocery_diary;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button button;
    ListView lview;
    EditText editetext;
    ArrayList<String> itemlist = new ArrayList<String>(1000);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.button);
        lview = findViewById(R.id.lview);
        editetext = findViewById(R.id.editetext);

    }

    public void add(View view){
        String input_item = editetext.getText().toString();
        editetext.setText("");
        if(!input_item.isEmpty()){
            itemlist.add(input_item);
            Toast.makeText(this, "saved", Toast.LENGTH_SHORT).show();
            ArrayAdapter<String> listad = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,itemlist);
            lview.setAdapter(listad);
        }
        else{
            Toast.makeText(this, "Empty item does not allowed here!!", Toast.LENGTH_SHORT).show();
        }
    }
    public String get_msg(){
        String mymsg = "";
        mymsg+="*Your List* \n";
        for(int i=0;i<29;i++){
            mymsg+="+";
        }
        mymsg+="\n \n";
        for(int i=0;i<itemlist.size();i++){
            int index = i+1;
            mymsg+=index+"."+itemlist.get(i)+"\n \n";
        }
        for(int i=0;i<29;i++){
            mymsg+="+";
        }
        return mymsg;
    }
    public void share(View view){
        String msg = get_msg();
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_TEXT,msg);
        intent.setType("text/plain");
        try{
            startActivity(intent);
        }
        catch(ActivityNotFoundException e){
            Toast.makeText(this, "Please Try Again", Toast.LENGTH_SHORT).show();
        }

    }

}
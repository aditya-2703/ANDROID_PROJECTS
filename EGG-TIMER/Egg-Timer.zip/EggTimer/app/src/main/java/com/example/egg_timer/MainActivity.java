package com.example.egg_timer;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView textView;
    SeekBar seekBar;
    Button button;
    boolean is_counter = false;
    CountDownTimer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView);
        seekBar  = findViewById(R.id.seekBar);

        seekBar.setProgress(30);
        seekBar.setMax(600);

        button = findViewById(R.id.button);



        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

                updateTimer(progress);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }


    public void reset(){
        textView.setText("0:30");
        seekBar.setProgress(30);
        seekBar.setEnabled(true);
        timer.cancel();
        button.setText("Go!");
        is_counter=false;
    }

    public void timer_start(View view){
        if (is_counter){
            textView.setText("0:30");
            seekBar.setProgress(30);
            seekBar.setEnabled(true);
            timer.cancel();
            button.setText("Go!");
            is_counter=false;

        }
        else{
            is_counter=true;
            seekBar.setEnabled(false);
            button.setText("STOP!");

            timer = new CountDownTimer(seekBar.getProgress()*1000,1000) {
                @Override
                public void onTick(long millisUntilFinished) {
                    updateTimer((int)millisUntilFinished/1000);
                }

                @Override
                public void onFinish() {
                    MediaPlayer mp = MediaPlayer.create(getApplicationContext(),R.raw.bell);
                    mp.start();
                    reset();
                }
            }.start();
        }


    }


    public void updateTimer(int secondleft){
        int minutes  = secondleft/60;
        int second = secondleft - (minutes * 60);
        String second_string = Integer.toString(second);

        if(second<=9){
            second_string = "0"+second_string;
        }
        textView.setText(Integer.toString(minutes)+":"+second_string);
    }

}
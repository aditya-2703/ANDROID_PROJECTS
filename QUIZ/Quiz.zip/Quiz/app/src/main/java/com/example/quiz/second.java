package com.example.quiz;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class second extends AppCompatActivity {

    TextView greeting,info;
    ImageView win,lose;
    public String score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent = getIntent();
        score = intent.getStringExtra(MainActivity.key);

        greeting = findViewById(R.id.greeting);
        info = findViewById(R.id.info);
        win = findViewById(R.id.win);

        int final_score = Integer.parseInt(score);

        if(final_score<=5){
            greeting.setText("More practice needed!");
            greeting.setTextColor(ContextCompat.getColor(getApplicationContext(),R.color.red));
            win.setImageResource(R.drawable.try_again);
        }
        else {
            greeting.setText("Congratulation");
        }
        info.setText("You got "+score+" out of 10.");

    }
    public void send(View view){
        String value="You got score *" +score+ " / 10* in Java from *Quiz* platform.";
        Intent intent =  new Intent(Intent.ACTION_SEND);
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_TEXT,value);
        try{
            startActivity(intent);
        }
        catch(ActivityNotFoundException e){
            Toast.makeText(this, "Try Again", Toast.LENGTH_SHORT).show();
        }
    }
}
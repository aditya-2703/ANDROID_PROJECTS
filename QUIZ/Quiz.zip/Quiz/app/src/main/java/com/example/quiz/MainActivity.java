package com.example.quiz;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    TextView question,result;
    Button yes, no;
    String[] questions = {"Was java found in 1991?",
            "Was java owned by microsoft?",
            "Java is platform independent?",
            "Java is dynamically typed language?",
            "Java is high level  language?",
            "Java is usefull for developing apps?",
            "Java uses interpreter?",
            "java is 100% object oriented language?",
            "Java does not supports polymorphism?",
            "'=='  is used to compare to strings?"};
    boolean[] answers = {true, false, true, false, true,true,false,false,false,false};
    public int score = 1;
    public int index = 0;
    public static String key = "score_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        question = findViewById(R.id.quest);
        result = findViewById(R.id.result);
        yes = findViewById(R.id.yes);
        no = findViewById(R.id.no);

        question.setText(questions[0]);

        

    }

    public void second_page_redirect(int score){
        String our_score = String.valueOf(score);
        Intent intent = new Intent(MainActivity.this,second.class);
        intent.putExtra(key,our_score);
        startActivity(intent);
    }
    public void yes(View view) {
        if (index < questions.length-1) {
            if (answers[index]) {
                score++;
            }
            question.setText(questions[++index]);
            result.setText("Score : " + score + " out of " + (questions.length));
        }
        else {
            second_page_redirect(score);
//            Toast.makeText(this, "Restart to play again..", Toast.LENGTH_SHORT).show();
        }
    }

    public void no(View view) {
        if (index < questions.length-1) {
            if (!answers[index]) {
                score++;
            }
            question.setText(questions[++index]);
            result.setText("Score : " + score + " out of " + (questions.length));

        } else {
            second_page_redirect(score);
//            Toast.makeText(this, "Restart to play again..", Toast.LENGTH_SHORT).show();

        }

    }


}
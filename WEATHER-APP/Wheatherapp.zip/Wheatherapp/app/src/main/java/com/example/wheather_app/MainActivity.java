package com.example.wheather_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    ImageView imageView;
    EditText cityname;
    TextView textView,weather_heading,weather_desc_heading;
    TextView desc;

    class Get_data extends AsyncTask<String,Void,String>{

        @Override
        protected String doInBackground(String... strings) {
            try {
                URL url = new URL(strings[0]);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                InputStream in = connection.getInputStream();
                InputStreamReader reader = new InputStreamReader(in);
                int data = reader.read();
                String result="";
                while (data!=-1){
                    char curr_char = (char)data;
                    result+=curr_char;
                    data=reader.read();
                }
                return result;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            try {

                String weather_main="";
                String weather_desc = "";

                JSONObject jobj = new JSONObject(s);
                String weather_info = jobj.getString("weather");
                JSONArray arr = new JSONArray(weather_info);
                for(int i=0;i<arr.length();i++){
                    JSONObject jsonparse = arr.getJSONObject(i);
                    weather_main = jsonparse.getString("main");
                    weather_desc = jsonparse.getString("description");
                }
                if(!weather_main.isEmpty() && !weather_desc.isEmpty()){
                    textView.setText(weather_main);
                    desc.setText(weather_desc);

                    String string = weather_main+weather_desc;
                    string = string.toLowerCase();
                    if(string.contains("rain")){
                        imageView.setImageResource(R.drawable.rain);
                    }
                    else if(string.contains("snow")){
                        imageView.setImageResource(R.drawable.snow);
                    }
                    else if(string.contains("thunder")){
                        imageView.setImageResource(R.drawable.thunderandlight);
                    }
                    else if(string.contains("ice")){
                        imageView.setImageResource(R.drawable.ice);
                    }
                    else if(string.contains("cloud")){
                        imageView.setImageResource(R.drawable.cloud);
                    }
                    else if(string.contains("fog")){
                        imageView.setImageResource(R.drawable.fog);
                    }
                    else if(string.contains("heat")){
                        imageView.setImageResource(R.drawable.hot);
                    }







                }
                else{
                    Toast.makeText(MainActivity.this, "Some Error Occures Please Try Again!", Toast.LENGTH_SHORT).show();
                }

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(MainActivity.this, "Try Again", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textView3);
        cityname = findViewById(R.id.city);
        desc = findViewById(R.id.textView5);
        weather_heading = findViewById(R.id.textView2);
        weather_desc_heading = findViewById(R.id.textView4);
        imageView = findViewById(R.id.imageView);

        weather_heading.setVisibility(View.INVISIBLE);
        weather_desc_heading.setVisibility(View.INVISIBLE);

    }
    public void action(View view){


        weather_heading.setVisibility(View.VISIBLE);
        weather_desc_heading.setVisibility(View.VISIBLE);

        String input_city=cityname.getText().toString();
        if(!input_city.isEmpty()){
            String url = "https://api.openweathermap.org/data/2.5/weather?q="+input_city+"&appid=1b5a3af5ada10c7042d9c96ff514926f";
            Get_data obj = new Get_data();
            try {
                String result = obj.execute(url).get();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Check Again Your Internet Connectivity", Toast.LENGTH_SHORT).show();
            }
        }
        else{
            Toast.makeText(this, "Please Enter Valid City Name!", Toast.LENGTH_SHORT).show();
        }

        InputMethodManager manager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        manager.hideSoftInputFromWindow(cityname.getWindowToken(),0);

    }
}